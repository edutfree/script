# Using deploy api

deploy hook usage:

https://github.com/acmesh-official/acme.sh/wiki/deployhooks

