#ifndef aegis256_soft_H
#define aegis256_soft_H

#include "implementations.h"

extern struct aegis256_implementation aegis256_soft_implementation;

#endif