#ifndef aegis256_aesni_H
#define aegis256_aesni_H

#include "implementations.h"

extern struct aegis256_implementation aegis256_aesni_implementation;

#endif